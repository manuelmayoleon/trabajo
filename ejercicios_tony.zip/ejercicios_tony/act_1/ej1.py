#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd

import numpy as np
import scipy.stats as ss
import math
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
from scipy import optimize


file = r'popu.csv'
#file = r'estad_wellbeing.csv'
#file = r'treering.csv'

df = pd.read_csv(file, delimiter=',')

v=pd.to_numeric(df['Year_2011'])
b=np.array(v)
a=np.array(v)

rango = 263
for i in range(rango):
    number=a[i]
    count = int(math.log10(number))
    
    first_digit = number // math.pow(10, count)
    a[i]=first_digit
    


print(first_digit)
rango = 263

#

            
       





num_bins=9
print('bien')

fig,ax = plt.subplots(1,1)

plt.xlabel('Primer dígito ')
plt.ylabel('Frecuencia ')
plt.title('Histograma de frecuencia de primer dígito')
plt.xlim(1,9)

n, bins, patches = ax.hist(a,num_bins, density = 'true', facecolor='blue',  alpha=0.5)


bins=bins[0:9] + (bins[1]-bins[0])/2

print(n)

print(bins)

plt.plot(bins,n, 'bo')

print('todo bien' )
def fit_func(x,a,b):
    return a*x**(b)


params, params_covariance = optimize.curve_fit(fit_func,bins,n,p0=[1,9])
print(params)
plt.plot(bins, fit_func(bins,params[0],params[1]))
plt.savefig('destination_path.eps', format='eps')
fig.savefig('myimage.pdf', format='pdf', dpi=1200)

        
        
