import random
import numpy as np
import scipy.stats as ss
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
from scipy import optimize

v=[]
rango=100000
iteraciones=10000


for i in range(rango):
    number = random.randrange(1,9)
   
    
    for i in range(iteraciones):
        decide=random.randrange(1,9)/10.
        if decide<0.5:
            number=number*2.
        else:
            number = number/2.
            
    v.append(number)
a = np.array(v)

#print(a)

#for i in range(rango):
#    
#    x=a[i]
#    if x>=1:
#        while x>=10:
#            x= x/10.
#            a[i] =  int(x)
#            
#    if x<=1:
#        
#        while x<10:
#            x=x*10.
#            
#        x=x/10.
#        a[i]=int(x)
#        
#        
#        




for i in range(rango):
 #   i=6       
    number = str(a[i])
    
    for k in range(len(number)):
       # print(number[k])
        if number[k]!='0' and number[k]!='.':
            numero=number[k]
            a[i]=int(numero)
            break
        
        

num_bins=9

fig,ax = plt.subplots(1,1)

plt.xlabel('Primer dígito más frecuente')
plt.ylabel('Frecuencia ')
plt.title('Histograma de frecuencia de primer dígito')
plt.xlim(1,9)

n, bins, patches = ax.hist(a,num_bins, density = 'true', facecolor='blue',  alpha=0.5)


bins=bins[0:9] + (bins[1]-bins[0])/2

print(n)

print(bins)

plt.plot(bins,n, 'bo')

print('todo bien' )
def fit_func(x,a,b):
    return a*x**(b)


params, params_covariance = optimize.curve_fit(fit_func,bins,n,p0=[1,9])
print(params)
plt.plot(bins, fit_func(bins,params[0],params[1]))
fig.savefig('im2.pdf', format='pdf', dpi=1200)
