clear all
clc
close all hidden %remover las gráficas generadas anteriormente
p=linspace(0,1,100);
alpha=2.1;
w=p.^((alpha-2)/(alpha-1));
plot(p,w,'linewidth',2)
grid on 
hold on
i=1;
while(alpha<3.5)
    
    alpha=alpha+0.2;
 w=p.^((alpha-2)/(alpha-1));
    plot(p,w,'linewidth',2,'color',rand(1,3))
    plota(i)=alpha;
    i=i+1;
end
plot(p,p,'--','linewidth',2)
title('Riqueza acumulada en fracciones de poblaci\''on ','Interpreter','latex','FontSize',20,'FontWeight','bold')
xlabel(' Porcentaje de poblaci\''on $P$','FontSize',20,'FontWeight','bold','Interpreter','latex')
ylabel(' Fracci\''on de riqueza $W$','FontSize',20,'FontWeight','bold','Interpreter','latex')
legend('$\alpha=2.1$','$\alpha=2.3$','$\alpha=2.5$','$\alpha=2.7$','$\alpha=2.9$','$\alpha=3.1$','$\alpha=3.5$','$\alpha=3.7$','$\alpha>>$', 'location', 'Northwest','Interpreter','latex')
