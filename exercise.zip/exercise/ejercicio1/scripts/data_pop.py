# !/ usr / bin / env python3
import pandas as pd
import numpy as np
import scipy . stats as ss
import math
import matplotlib . mlab as mlab
import matplotlib . pyplot as plt
from scipy import optimize




df = pd.read_csv('pop.csv' , delimiter = ',')




v = pd.to_numeric (df['Years'])
b = np.array (v)
a = np.array (v)

print(a)
#obtener el primer dígito de la serie de números
rango = 7090
for i in range ( rango ) :
    number = a[i]
    #a[i]=  int(str(number)[:1])
    a[i]=int(str(a[i])[:1])


print ( a )





# Esta parte simplemente sirve para poder plotear a la vez
# el fit y el histograma
num_bins =9


fig , ax = plt.subplots (1 ,1)





plt.xlabel ( ' Primer dígito ')
plt.ylabel ( ' Frecuencia ')
plt.title ( ' Histograma de frecuencia de primer dígito en población mundial  \n (1995-2016) ')
plt.xlim (1 ,9)

# Hacer el histograma 
n,bins,patches = ax.hist(a,num_bins,density ='true',facecolor ='green',alpha =0.2,edgecolor='yellow')



bins = bins[0:9] + ( bins[1] - bins[0])/2
print('FREQUENCY')
print (n)
print('bins')

print (bins)


plt.plot (bins,n,'bo',color='green',alpha=0.6)


#Hacer el fiting de la ley de potencias

def fit_func (x ,a , b ) :
    return a * x **( b )

params , params_covariance = optimize.curve_fit(fit_func,bins,n,method='dogbox')
print('param')
print (params)
plt.plot(bins,fit_func(bins,params[0],params[1]),alpha=0.9,color='red')
plt.savefig ('destination_path.eps',format ='eps')
fig.savefig ('myimage.pdf',format ='pdf',dpi=1200)