clear all
clc
close all hidden %remover las gráficas generadas anteriormente
A=load('rand.txt');
B=load('freq.txt');

c=[1.5:9.5];
c=c.';

c=log(c);
d=log(B/(sum(B)));
% figure(2)
% plot(c,d,'o')
% grid on
% title('Representaci\''on en escala log','Interpreter','latex','FontSize',20,'FontWeight','bold')
% xlabel('$log(x)$','FontSize',20,'FontWeight','bold','Interpreter','latex')
% ylabel(' $log(p)$','FontSize',20,'FontWeight','bold','Interpreter','latex')
% [p,q]=linreg(c,d,0,3);


%%hacemos el histograma%%%%%%%%%%%%%%%%%%%
%
%edges = hh.BinEdges; Valores en el eje x
%counts = hh.BinCounts; frecuencias 
%values = hh.Values; valores
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
h=histogram(A,9,'Normalization','probability');
hold on
grid on
xval=h.BinEdges;
for i=2:length(xval)
    xmed(i-1)=xval(i-1)+(xval(i)-xval(i-1))/2;
end
freq=h.BinCounts;
freq=freq/sum(freq);
logx=log(xmed);
logf=log(freq);
xx = linspace(min(xmed),max(xmed),100);
[p,q]=linreg(logx,logf,0,3);
%Interpolación polinomial realizada con los coeficientes de la regresion
%lineal
figure(1)
inter=exp(p(2)).*((xx).^p(1));
plot(xx,inter)
plot(xx,inter,'-','LineWidth',2)

%histfit((A(:,1)+6)/12,30,'beta') fitting maxwelliana
title('Histograma de frecuencia de primer d\''igito ','Interpreter','latex','FontSize',20,'FontWeight','bold')
xlabel('$x$','FontSize',20,'FontWeight','bold','Interpreter','latex')
ylabel(' $freq$','FontSize',20,'FontWeight','bold','Interpreter','latex')
%legend('v_y', 'location', 'Northwest','Interpreter','latex')


