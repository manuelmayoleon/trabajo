function [p,rsq] = linreg(x,y,errory,fig)
%%%Regresion lineal%%%
%te devuelve los coeficientes p(1)*X+p(2) y el R^2
[p,S] = polyfit(x,y,1); % Y=p(1)*x + p(2) 
yfit = polyval(p,x);
%calculamos el coef de correlacion R^2 
yresid = y - yfit;
SSresid = sum(yresid.^2);
SStotal = (length(y)-1) * var(y) ;
rsq=1-SSresid/SStotal;
fprintf('-------------Regresión lineal-----------------\n')
fprintf(' Ecuación de ajuste y=%f*x +%f \n' ,p(1),p(2))
fprintf('-----------------------------------------------\n')
fprintf('coeficiente de correlación R^2 =%f \n', rsq)
xp=linspace(0,max(x),2000);
yp=p(1)*xp+p(2);
xerror=ones(length(x),1);
yerror=zeros(length(y),1);
    for i=1:length(y)
        yerror(i)=errory;
    end
xerrorn=xerror;
yerrorn=yerror;
%plot(x,y,'o')
% grid on
% hold on
figure(fig)
%errorbar(x,y,yerrorn,yerror,xerrorn,xerror,'o','MarkerSize',12) %si
%quieres poner barras de error
plot(x,y,'o','MarkerSize',12)
grid on
hold on
plot(xp,yp,'--','LineWidth',2)
str=compose("%1.6f",p(1));
str2=compose("%1.3f",p(2));
rs=compose("%1.6f",rsq);
title('Ajuste lineal','Interpreter','latex','FontSize',20,'FontWeight','bold')
xlabel('$ln(x)$','FontSize',20,'FontWeight','bold','Interpreter','latex')
ylabel('$ln(p) $ ','FontSize',20,'FontWeight','bold','Interpreter','latex')
legend('Valores obtenidos',sprintf('$ln(p(x))=$%s$ln(x)$%s  \n $R^2=$%s' ,str,str2,rs),'FontSize',20,'Location','Best','Interpreter','latex')
end